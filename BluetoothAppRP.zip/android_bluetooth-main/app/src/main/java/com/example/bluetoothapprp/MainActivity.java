package com.example.bluetoothapprp;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_BLUETOOTH_PERMISSIONS = 1001;
    private static final int REQUEST_STORAGE_PERMISSIONS = 1002;

    private BluetoothAdapter bluetoothAdapter;
    private ArrayList<String> pairedDevicesList;
    private ArrayAdapter<String> arrayAdapter;
    private ListView deviceListView;

    private TextView tvConnectedDevice;

    // Receiver for Bluetooth name change
    private final BroadcastReceiver bluetoothNameReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (BluetoothAdapter.ACTION_LOCAL_NAME_CHANGED.equals(intent.getAction())) {
                String newName = bluetoothAdapter.getName();
                tvConnectedDevice.setText("Bluetooth Name: " + newName);
            }
        }
    };

    // File picker
    private final ActivityResultLauncher<String> filePicker =
            registerForActivityResult(new ActivityResultContracts.GetContent(),
                    uri -> {
                        if (uri != null) {
                            sendFile(uri);
                        } else {
                            Toast.makeText(this, "No file selected", Toast.LENGTH_SHORT).show();
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        // Views
        Button enableBluetoothBtn = findViewById(R.id.btnOn);
        Button disableBluetoothBtn = findViewById(R.id.btnOff);
        Button sendFileBtn = findViewById(R.id.btnsendfile);
        Button pairedDevicesBtn = findViewById(R.id.btnDevices);
        deviceListView = findViewById(R.id.device_list);
        tvConnectedDevice = findViewById(R.id.tvConnectedDevice); // ✅ fixed ID

        pairedDevicesList = new ArrayList<>();
        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, pairedDevicesList);
        deviceListView.setAdapter(arrayAdapter);

        // Set phone’s current Bluetooth name
        if (bluetoothAdapter != null) {
            tvConnectedDevice.setText("Bluetooth Name: " + bluetoothAdapter.getName());
        } else {
            tvConnectedDevice.setText("Bluetooth not supported");
        }

        // Register receiver for Bluetooth name changes
        IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_LOCAL_NAME_CHANGED);
        registerReceiver(bluetoothNameReceiver, filter);

        // Button listeners
        enableBluetoothBtn.setOnClickListener(v -> enableBluetooth());
        disableBluetoothBtn.setOnClickListener(v -> disableBluetooth());
        pairedDevicesBtn.setOnClickListener(v -> showPairedDevices());
        sendFileBtn.setOnClickListener(v -> pickFile());

        checkBluetoothPermissions();
        checkStoragePermissions();
    }

    // ==== Permissions ====
    private void checkBluetoothPermissions() {
        String[] bluetoothPermissions = {
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
        };

        ArrayList<String> missing = new ArrayList<>();
        for (String perm : bluetoothPermissions) {
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                missing.add(perm);
            }
        }

        if (!missing.isEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toArray(new String[0]), REQUEST_BLUETOOTH_PERMISSIONS);
        }
    }

    private void checkStoragePermissions() {
        String[] storagePermissions;

        if (Build.VERSION.SDK_INT >= 33) {
            storagePermissions = new String[]{
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.READ_MEDIA_AUDIO
            };
        } else {
            storagePermissions = new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE
            };
        }

        ArrayList<String> missing = new ArrayList<>();
        for (String perm : storagePermissions) {
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                missing.add(perm);
            }
        }

        if (!missing.isEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toArray(new String[0]), REQUEST_STORAGE_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_BLUETOOTH_PERMISSIONS || requestCode == REQUEST_STORAGE_PERMISSIONS) {
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Some permissions were denied", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            Toast.makeText(this, "Permissions granted", Toast.LENGTH_SHORT).show();
        }
    }

    // ==== Bluetooth logic ====
    private void enableBluetooth() {
        if (bluetoothAdapter != null && !bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivity(enableBtIntent);
        } else {
            Toast.makeText(this, "Bluetooth is already enabled", Toast.LENGTH_SHORT).show();
        }
    }

    private void disableBluetooth() {
        if (bluetoothAdapter != null && bluetoothAdapter.isEnabled()) {
            // ❌ disable() is blocked on Android 10+ → open settings instead
            Intent intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
            startActivity(intent);
            Toast.makeText(this, "Turn off Bluetooth from settings", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Bluetooth is already disabled", Toast.LENGTH_SHORT).show();
        }
    }

    private void showPairedDevices() {
        if (bluetoothAdapter != null && bluetoothAdapter.isEnabled()) {
            Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
            pairedDevicesList.clear();
            for (BluetoothDevice device : pairedDevices) {
                pairedDevicesList.add(device.getName() + " (" + device.getAddress() + ")");
            }
            arrayAdapter.notifyDataSetChanged();

            if (pairedDevicesList.isEmpty()) {
                Toast.makeText(this, "No paired devices found", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please enable Bluetooth", Toast.LENGTH_SHORT).show();
        }
    }

    // ==== File sharing ====
    private void pickFile() {
        filePicker.launch("*/*"); // open file picker
    }

    private void sendFile(Uri fileUri) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_STREAM, fileUri);
        intent.setType("*/*");
        intent.setPackage("com.android.bluetooth"); // directly open Bluetooth share
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Bluetooth sharing not available", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(bluetoothNameReceiver); // cleanup
    }
}
